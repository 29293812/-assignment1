﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace VIRTUAL_MEMORY
{
    public partial class Form1 : Form
    {
        public OleDbConnection connection = new OleDbConnection(Properties.Settings.Default.virtualConnectionString);
        public OleDbConnection cone = new OleDbConnection(Properties.Settings.Default.TLB__tableConnectionString);
      
        public Form1()
        {
            InitializeComponent();
        }

        Form2 fs = new Form2();
        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'virtualDataSet5.physical_Memory' table. You can move, or remove it, as needed.
            this.physical_MemoryTableAdapter.Fill(this.virtualDataSet5.physical_Memory);
            // TODO: This line of code loads data into the 'tLB__tableDataSet2.TLB_Table' table. You can move, or remove it, as needed.
            this.tLB_TableTableAdapter2.Fill(this.tLB__tableDataSet2.TLB_Table);
            // TODO: This line of code loads data into the 'database4DataSet1.TLB' table. You can move, or remove it, as needed.
            this.tLBTableAdapter1.Fill(this.database4DataSet1.TLB);
            // TODO: This line of code loads data into the 'tLB__tableDataSet1.TLB_Table' table. You can move, or remove it, as needed.
            this.tLB_TableTableAdapter1.Fill(this.tLB__tableDataSet1.TLB_Table);
            // TODO: This line of code loads data into the 'tLB__tableDataSet.TLB_Table' table. You can move, or remove it, as needed.
            //this.tLB_TableTableAdapter.Fill(this.tLB__tableDataSet.TLB_Table);
            // TODO: This line of code loads data into the 'database4DataSet.TLB' table. You can move, or remove it, as needed.
           // this.tLBTableAdapter.Fill(this.database4DataSet.TLB);

        }

        private void btnE_Click(object sender, EventArgs e)
        {
            connection.Open();
            OleDbCommand command = new OleDbCommand();
            command.Connection = connection;
            command.CommandText = "select * from [Physical Memory] where  Process='" + txtPro.Text + "'";
            OleDbDataReader reader = command.ExecuteReader();

            int count = 0;
            while (reader.Read())
            {
                count = count + 1;
            }
            OleDbDataReader myReader = null;
            if (count == 1)
            {
                MessageBox.Show("Page is Found!", "", MessageBoxButtons.OK, MessageBoxIcon.Information);



                OleDbCommand myCom = new OleDbCommand("Select Frame_no From [Physical Memory] Where  Process='" + txtPro.Text + "'", connection);
                myReader = myCom.ExecuteReader();
                while (myReader.Read())
                {
                    lblPHY.Text ="Physical address frame no is : "+ myReader["Frame_no"].ToString();

                }
            }
            else if (count > 1)
            {
                MessageBox.Show("Duplicate page no");
            }
            else
            {
                MessageBox.Show("Page is not Found go and fetch a page in a disk ", "Page Fault", MessageBoxButtons.OKCancel, MessageBoxIcon.Error);
                btnF.Focus();
            }
             connection.Close();
        }
       
        private void btnF_Click(object sender, EventArgs e)
        {
            fs.Show();
        }

        private void lblPHY_Click(object sender, EventArgs e)
        { }
        public void display()
        {
            connection.Open();
            OleDbDataAdapter ada = new OleDbDataAdapter("Select * From [Physical Memory]", connection);
            DataSet ds = new DataSet();
            ada.Fill(ds, "Tebogo");
            dataGridView2.DataSource = ds;
            dataGridView2.DataMember = "Tebogo";
            connection.Close();

        }
        public void display1()
        {
            cone.Open();
            OleDbDataAdapter ada = new OleDbDataAdapter("Select * From [TLB Table]", cone);
            DataSet ds = new DataSet();
            ada.Fill(ds, "Tebogo");
            dataGridView1.DataSource = ds;
            dataGridView1.DataMember = "Tebogo";
            cone.Close();

        }
        private void btnUp_Click(object sender, EventArgs e)
        {         
            cone.Open();
            try
            {
                OleDbCommand cod = new OleDbCommand();
                cod.Connection = cone;
                cod.CommandText = "INSERT INTO [TLB Table]([Page_Frame_Number],[Physical_Page_Number])  VALUES('" + Form2.SetValueForText2 + "','" + Form2.SetValueForText1 + "') ";
                cod.ExecuteNonQuery();
                OleDbDataReader myReader = null;
                MessageBox.Show("TLB Updated! ", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
                while (myReader.Read())
                {
                    label1.Text += "" + myReader["Physical_Page_Number"].ToString();

                }
                
                
            }
            catch (Exception)
            {
                MessageBox.Show("duplicate page!", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            cone.Close();
            display1();
            lblPHY.Text = "Physical address frame no is : " + Form2.SetValueForText1;

        }

        private void datatlb_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            /* int LinearSearch( int[]arr, int val)
            {
                foreach()
            }*/
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }
    }
}

