﻿namespace VIRTUAL_MEMORY
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.btnpR = new System.Windows.Forms.Button();
            this.physical_MemoryBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.virtualDataSet = new VIRTUAL_MEMORY.virtualDataSet();
            this.btnUp = new System.Windows.Forms.Button();
            this.txtPro = new System.Windows.Forms.TextBox();
            this.lblProcess = new System.Windows.Forms.Label();
            this.txtEX = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtFr = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.button1 = new System.Windows.Forms.Button();
            this.physical_MemoryTableAdapter = new VIRTUAL_MEMORY.virtualDataSetTableAdapters.physical_MemoryTableAdapter();
            this.tableAdapterManager = new VIRTUAL_MEMORY.virtualDataSetTableAdapters.TableAdapterManager();
            this.virtualDataSet1 = new VIRTUAL_MEMORY.virtualDataSet1();
            this.physical_MemoryBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.physical_MemoryTableAdapter1 = new VIRTUAL_MEMORY.virtualDataSet1TableAdapters.physical_MemoryTableAdapter();
            this.tableAdapterManager1 = new VIRTUAL_MEMORY.virtualDataSet1TableAdapters.TableAdapterManager();
            this.virtualDataSet2 = new VIRTUAL_MEMORY.virtualDataSet2();
            this.physical_MemoryBindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            this.physical_MemoryTableAdapter2 = new VIRTUAL_MEMORY.virtualDataSet2TableAdapters.physical_MemoryTableAdapter();
            this.tableAdapterManager2 = new VIRTUAL_MEMORY.virtualDataSet2TableAdapters.TableAdapterManager();
            this.virtualDataSet3 = new VIRTUAL_MEMORY.virtualDataSet3();
            this.physical_MemoryBindingSource3 = new System.Windows.Forms.BindingSource(this.components);
            this.physical_MemoryTableAdapter3 = new VIRTUAL_MEMORY.virtualDataSet3TableAdapters.physical_MemoryTableAdapter();
            this.tableAdapterManager3 = new VIRTUAL_MEMORY.virtualDataSet3TableAdapters.TableAdapterManager();
            this.virtualDataSet5 = new VIRTUAL_MEMORY.virtualDataSet5();
            this.physical_MemoryBindingSource4 = new System.Windows.Forms.BindingSource(this.components);
            this.physical_MemoryTableAdapter4 = new VIRTUAL_MEMORY.virtualDataSet5TableAdapters.physical_MemoryTableAdapter();
            this.tableAdapterManager4 = new VIRTUAL_MEMORY.virtualDataSet5TableAdapters.TableAdapterManager();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.database4DataSet1 = new VIRTUAL_MEMORY.Database4DataSet1();
            this.tLBBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tLBTableAdapter = new VIRTUAL_MEMORY.Database4DataSet1TableAdapters.TLBTableAdapter();
            this.tableAdapterManager5 = new VIRTUAL_MEMORY.Database4DataSet1TableAdapters.TableAdapterManager();
            this.physicalPageNumberDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.processDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.frameNoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.physical_MemoryBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.virtualDataSet)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.virtualDataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.physical_MemoryBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.virtualDataSet2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.physical_MemoryBindingSource2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.virtualDataSet3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.physical_MemoryBindingSource3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.virtualDataSet5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.physical_MemoryBindingSource4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.database4DataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tLBBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // btnpR
            // 
            this.btnpR.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnpR.Location = new System.Drawing.Point(249, 56);
            this.btnpR.Name = "btnpR";
            this.btnpR.Size = new System.Drawing.Size(140, 38);
            this.btnpR.TabIndex = 1;
            this.btnpR.Text = "Page removal";
            this.btnpR.UseVisualStyleBackColor = true;
            this.btnpR.Click += new System.EventHandler(this.btnpR_Click);
            // 
            // physical_MemoryBindingSource
            // 
            this.physical_MemoryBindingSource.DataMember = "physical Memory";
            this.physical_MemoryBindingSource.DataSource = this.virtualDataSet;
            // 
            // virtualDataSet
            // 
            this.virtualDataSet.DataSetName = "virtualDataSet";
            this.virtualDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // btnUp
            // 
            this.btnUp.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUp.Location = new System.Drawing.Point(238, 116);
            this.btnUp.Name = "btnUp";
            this.btnUp.Size = new System.Drawing.Size(152, 115);
            this.btnUp.TabIndex = 2;
            this.btnUp.Text = "Update Physical Memory";
            this.btnUp.UseVisualStyleBackColor = true;
            this.btnUp.Click += new System.EventHandler(this.btnUp_Click);
            // 
            // txtPro
            // 
            this.txtPro.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPro.Location = new System.Drawing.Point(132, 205);
            this.txtPro.Name = "txtPro";
            this.txtPro.Size = new System.Drawing.Size(100, 26);
            this.txtPro.TabIndex = 7;
            // 
            // lblProcess
            // 
            this.lblProcess.AutoSize = true;
            this.lblProcess.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProcess.Location = new System.Drawing.Point(37, 208);
            this.lblProcess.Name = "lblProcess";
            this.lblProcess.Size = new System.Drawing.Size(46, 18);
            this.lblProcess.TabIndex = 6;
            this.lblProcess.Text = "Page";
            // 
            // txtEX
            // 
            this.txtEX.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtEX.Location = new System.Drawing.Point(132, 56);
            this.txtEX.Name = "txtEX";
            this.txtEX.Size = new System.Drawing.Size(100, 26);
            this.txtEX.TabIndex = 9;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(37, 56);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(67, 18);
            this.label1.TabIndex = 8;
            this.label1.Text = "AL page";
            // 
            // txtFr
            // 
            this.txtFr.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtFr.Location = new System.Drawing.Point(132, 129);
            this.txtFr.Name = "txtFr";
            this.txtFr.Size = new System.Drawing.Size(100, 26);
            this.txtFr.TabIndex = 11;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(37, 129);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(77, 18);
            this.label2.TabIndex = 10;
            this.label2.Text = "AL Frame";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.dataGridView1);
            this.groupBox1.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(4, 18);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox1.Size = new System.Drawing.Size(439, 875);
            this.groupBox1.TabIndex = 12;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Physical Address";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.btnpR);
            this.groupBox2.Controls.Add(this.txtFr);
            this.groupBox2.Controls.Add(this.btnUp);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.lblProcess);
            this.groupBox2.Controls.Add(this.txtEX);
            this.groupBox2.Controls.Add(this.txtPro);
            this.groupBox2.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(451, 45);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox2.Size = new System.Drawing.Size(396, 375);
            this.groupBox2.TabIndex = 13;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Page Algo Perfomance ";
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(543, 528);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(220, 40);
            this.button1.TabIndex = 12;
            this.button1.Text = "Update TLB";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // physical_MemoryTableAdapter
            // 
            this.physical_MemoryTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.physical_MemoryTableAdapter = this.physical_MemoryTableAdapter;
            this.tableAdapterManager.UpdateOrder = VIRTUAL_MEMORY.virtualDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // virtualDataSet1
            // 
            this.virtualDataSet1.DataSetName = "virtualDataSet1";
            this.virtualDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // physical_MemoryBindingSource1
            // 
            this.physical_MemoryBindingSource1.DataMember = "physical Memory";
            this.physical_MemoryBindingSource1.DataSource = this.virtualDataSet1;
            // 
            // physical_MemoryTableAdapter1
            // 
            this.physical_MemoryTableAdapter1.ClearBeforeFill = true;
            // 
            // tableAdapterManager1
            // 
            this.tableAdapterManager1.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager1.physical_MemoryTableAdapter = this.physical_MemoryTableAdapter1;
            this.tableAdapterManager1.UpdateOrder = VIRTUAL_MEMORY.virtualDataSet1TableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // virtualDataSet2
            // 
            this.virtualDataSet2.DataSetName = "virtualDataSet2";
            this.virtualDataSet2.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // physical_MemoryBindingSource2
            // 
            this.physical_MemoryBindingSource2.DataMember = "physical Memory";
            this.physical_MemoryBindingSource2.DataSource = this.virtualDataSet2;
            // 
            // physical_MemoryTableAdapter2
            // 
            this.physical_MemoryTableAdapter2.ClearBeforeFill = true;
            // 
            // tableAdapterManager2
            // 
            this.tableAdapterManager2.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager2.physical_MemoryTableAdapter = this.physical_MemoryTableAdapter2;
            this.tableAdapterManager2.UpdateOrder = VIRTUAL_MEMORY.virtualDataSet2TableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // virtualDataSet3
            // 
            this.virtualDataSet3.DataSetName = "virtualDataSet3";
            this.virtualDataSet3.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // physical_MemoryBindingSource3
            // 
            this.physical_MemoryBindingSource3.DataMember = "physical Memory";
            this.physical_MemoryBindingSource3.DataSource = this.virtualDataSet3;
            // 
            // physical_MemoryTableAdapter3
            // 
            this.physical_MemoryTableAdapter3.ClearBeforeFill = true;
            // 
            // tableAdapterManager3
            // 
            this.tableAdapterManager3.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager3.physical_MemoryTableAdapter = this.physical_MemoryTableAdapter3;
            this.tableAdapterManager3.UpdateOrder = VIRTUAL_MEMORY.virtualDataSet3TableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // virtualDataSet5
            // 
            this.virtualDataSet5.DataSetName = "virtualDataSet5";
            this.virtualDataSet5.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // physical_MemoryBindingSource4
            // 
            this.physical_MemoryBindingSource4.DataMember = "physical Memory";
            this.physical_MemoryBindingSource4.DataSource = this.virtualDataSet5;
            // 
            // physical_MemoryTableAdapter4
            // 
            this.physical_MemoryTableAdapter4.ClearBeforeFill = true;
            // 
            // tableAdapterManager4
            // 
            this.tableAdapterManager4.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager4.physical_MemoryTableAdapter = this.physical_MemoryTableAdapter4;
            this.tableAdapterManager4.UpdateOrder = VIRTUAL_MEMORY.virtualDataSet5TableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.physicalPageNumberDataGridViewTextBoxColumn,
            this.processDataGridViewTextBoxColumn,
            this.frameNoDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.tLBBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(7, 27);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowTemplate.Height = 28;
            this.dataGridView1.Size = new System.Drawing.Size(425, 262);
            this.dataGridView1.TabIndex = 0;
            // 
            // database4DataSet1
            // 
            this.database4DataSet1.DataSetName = "Database4DataSet1";
            this.database4DataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tLBBindingSource
            // 
            this.tLBBindingSource.DataMember = "TLB";
            this.tLBBindingSource.DataSource = this.database4DataSet1;
            // 
            // tLBTableAdapter
            // 
            this.tLBTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager5
            // 
            this.tableAdapterManager5.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager5.TLBTableAdapter = this.tLBTableAdapter;
            this.tableAdapterManager5.UpdateOrder = VIRTUAL_MEMORY.Database4DataSet1TableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // physicalPageNumberDataGridViewTextBoxColumn
            // 
            this.physicalPageNumberDataGridViewTextBoxColumn.DataPropertyName = "Physical_Page_Number";
            this.physicalPageNumberDataGridViewTextBoxColumn.HeaderText = "Physical_Page_Number";
            this.physicalPageNumberDataGridViewTextBoxColumn.Name = "physicalPageNumberDataGridViewTextBoxColumn";
            // 
            // processDataGridViewTextBoxColumn
            // 
            this.processDataGridViewTextBoxColumn.DataPropertyName = "Process";
            this.processDataGridViewTextBoxColumn.HeaderText = "Process";
            this.processDataGridViewTextBoxColumn.Name = "processDataGridViewTextBoxColumn";
            // 
            // frameNoDataGridViewTextBoxColumn
            // 
            this.frameNoDataGridViewTextBoxColumn.DataPropertyName = "Frame_No";
            this.frameNoDataGridViewTextBoxColumn.HeaderText = "Frame_No";
            this.frameNoDataGridViewTextBoxColumn.Name = "frameNoDataGridViewTextBoxColumn";
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(860, 865);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form2";
            this.Text = "PHYSICAL MEMORY";
            this.Load += new System.EventHandler(this.Form2_Load);
            ((System.ComponentModel.ISupportInitialize)(this.physical_MemoryBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.virtualDataSet)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.virtualDataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.physical_MemoryBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.virtualDataSet2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.physical_MemoryBindingSource2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.virtualDataSet3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.physical_MemoryBindingSource3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.virtualDataSet5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.physical_MemoryBindingSource4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.database4DataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tLBBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private virtualDataSet virtualDataSet;
        private System.Windows.Forms.BindingSource physical_MemoryBindingSource;
        private virtualDataSetTableAdapters.physical_MemoryTableAdapter physical_MemoryTableAdapter;
        private virtualDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.Button btnpR;
        private System.Windows.Forms.Button btnUp;
        private System.Windows.Forms.TextBox txtPro;
        private System.Windows.Forms.Label lblProcess;
        private System.Windows.Forms.TextBox txtEX;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtFr;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button button1;
        private virtualDataSet1 virtualDataSet1;
        private System.Windows.Forms.BindingSource physical_MemoryBindingSource1;
        private virtualDataSet1TableAdapters.physical_MemoryTableAdapter physical_MemoryTableAdapter1;
        private virtualDataSet1TableAdapters.TableAdapterManager tableAdapterManager1;
        private virtualDataSet2 virtualDataSet2;
        private System.Windows.Forms.BindingSource physical_MemoryBindingSource2;
        private virtualDataSet2TableAdapters.physical_MemoryTableAdapter physical_MemoryTableAdapter2;
        private virtualDataSet2TableAdapters.TableAdapterManager tableAdapterManager2;
        private virtualDataSet3 virtualDataSet3;
        private System.Windows.Forms.BindingSource physical_MemoryBindingSource3;
        private virtualDataSet3TableAdapters.physical_MemoryTableAdapter physical_MemoryTableAdapter3;
        private virtualDataSet3TableAdapters.TableAdapterManager tableAdapterManager3;
        private virtualDataSet5 virtualDataSet5;
        private System.Windows.Forms.BindingSource physical_MemoryBindingSource4;
        private virtualDataSet5TableAdapters.physical_MemoryTableAdapter physical_MemoryTableAdapter4;
        private virtualDataSet5TableAdapters.TableAdapterManager tableAdapterManager4;
        private System.Windows.Forms.DataGridView dataGridView1;
        private Database4DataSet1 database4DataSet1;
        private System.Windows.Forms.BindingSource tLBBindingSource;
        private Database4DataSet1TableAdapters.TLBTableAdapter tLBTableAdapter;
        private Database4DataSet1TableAdapters.TableAdapterManager tableAdapterManager5;
        private System.Windows.Forms.DataGridViewTextBoxColumn physicalPageNumberDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn processDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn frameNoDataGridViewTextBoxColumn;
    }
}