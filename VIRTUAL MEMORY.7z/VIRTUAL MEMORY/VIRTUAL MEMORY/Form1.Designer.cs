﻿namespace VIRTUAL_MEMORY
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.tLBBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.database4DataSet = new VIRTUAL_MEMORY.Database4DataSet();
            this.lblProcess = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lblPHY = new System.Windows.Forms.Label();
            this.txtPro = new System.Windows.Forms.TextBox();
            this.btnE = new System.Windows.Forms.Button();
            this.btnF = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnUp = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.tLB_TableBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tLB__tableDataSet = new VIRTUAL_MEMORY.TLB__tableDataSet();
            this.tLBTableAdapter = new VIRTUAL_MEMORY.Database4DataSetTableAdapters.TLBTableAdapter();
            this.tableAdapterManager = new VIRTUAL_MEMORY.Database4DataSetTableAdapters.TableAdapterManager();
            this.tLB_TableTableAdapter = new VIRTUAL_MEMORY.TLB__tableDataSetTableAdapters.TLB_TableTableAdapter();
            this.tableAdapterManager1 = new VIRTUAL_MEMORY.TLB__tableDataSetTableAdapters.TableAdapterManager();
            this.tLB__tableDataSet1 = new VIRTUAL_MEMORY.TLB__tableDataSet1();
            this.tLB_TableBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.tLB_TableTableAdapter1 = new VIRTUAL_MEMORY.TLB__tableDataSet1TableAdapters.TLB_TableTableAdapter();
            this.tableAdapterManager2 = new VIRTUAL_MEMORY.TLB__tableDataSet1TableAdapters.TableAdapterManager();
            this.database4DataSet1 = new VIRTUAL_MEMORY.Database4DataSet1();
            this.tLBBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.tLBTableAdapter1 = new VIRTUAL_MEMORY.Database4DataSet1TableAdapters.TLBTableAdapter();
            this.tableAdapterManager3 = new VIRTUAL_MEMORY.Database4DataSet1TableAdapters.TableAdapterManager();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.tLB__tableDataSet2 = new VIRTUAL_MEMORY.TLB__tableDataSet2();
            this.tLB_TableBindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            this.tLB_TableTableAdapter2 = new VIRTUAL_MEMORY.TLB__tableDataSet2TableAdapters.TLB_TableTableAdapter();
            this.tableAdapterManager4 = new VIRTUAL_MEMORY.TLB__tableDataSet2TableAdapters.TableAdapterManager();
            this.pageFrameNumberDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.physicalPageNumberDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.virtualDataSet5 = new VIRTUAL_MEMORY.virtualDataSet5();
            this.physical_MemoryBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.physical_MemoryTableAdapter = new VIRTUAL_MEMORY.virtualDataSet5TableAdapters.physical_MemoryTableAdapter();
            this.tableAdapterManager5 = new VIRTUAL_MEMORY.virtualDataSet5TableAdapters.TableAdapterManager();
            this.frameNoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.processDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.physicalPageNoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.tLBBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.database4DataSet)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tLB_TableBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tLB__tableDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tLB__tableDataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tLB_TableBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.database4DataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tLBBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tLB__tableDataSet2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tLB_TableBindingSource2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.virtualDataSet5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.physical_MemoryBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // tLBBindingSource
            // 
            this.tLBBindingSource.DataMember = "TLB";
            this.tLBBindingSource.DataSource = this.database4DataSet;
            // 
            // database4DataSet
            // 
            this.database4DataSet.DataSetName = "Database4DataSet";
            this.database4DataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // lblProcess
            // 
            this.lblProcess.AutoSize = true;
            this.lblProcess.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProcess.Location = new System.Drawing.Point(12, 58);
            this.lblProcess.Name = "lblProcess";
            this.lblProcess.Size = new System.Drawing.Size(66, 18);
            this.lblProcess.TabIndex = 2;
            this.lblProcess.Text = "Process";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(8, 18);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(175, 18);
            this.label1.TabIndex = 3;
            this.label1.Text = "Virtual Address page no";
            // 
            // lblPHY
            // 
            this.lblPHY.AutoSize = true;
            this.lblPHY.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPHY.Location = new System.Drawing.Point(12, 108);
            this.lblPHY.Name = "lblPHY";
            this.lblPHY.Size = new System.Drawing.Size(193, 18);
            this.lblPHY.TabIndex = 4;
            this.lblPHY.Text = "Physical Address frame no";
            this.lblPHY.Click += new System.EventHandler(this.lblPHY_Click);
            // 
            // txtPro
            // 
            this.txtPro.Location = new System.Drawing.Point(165, 54);
            this.txtPro.Name = "txtPro";
            this.txtPro.Size = new System.Drawing.Size(216, 26);
            this.txtPro.TabIndex = 5;
            // 
            // btnE
            // 
            this.btnE.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnE.Location = new System.Drawing.Point(28, 262);
            this.btnE.Name = "btnE";
            this.btnE.Size = new System.Drawing.Size(82, 42);
            this.btnE.TabIndex = 6;
            this.btnE.Text = "Enter";
            this.btnE.UseVisualStyleBackColor = true;
            this.btnE.Click += new System.EventHandler(this.btnE_Click);
            // 
            // btnF
            // 
            this.btnF.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnF.Location = new System.Drawing.Point(328, 262);
            this.btnF.Name = "btnF";
            this.btnF.Size = new System.Drawing.Size(118, 42);
            this.btnF.TabIndex = 7;
            this.btnF.Text = "Fetch Page";
            this.btnF.UseVisualStyleBackColor = true;
            this.btnF.Click += new System.EventHandler(this.btnF_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.dataGridView2);
            this.groupBox1.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(579, 40);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox1.Size = new System.Drawing.Size(540, 311);
            this.groupBox1.TabIndex = 8;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Page Table";
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // btnUp
            // 
            this.btnUp.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUp.Location = new System.Drawing.Point(88, 583);
            this.btnUp.Name = "btnUp";
            this.btnUp.Size = new System.Drawing.Size(220, 55);
            this.btnUp.TabIndex = 9;
            this.btnUp.Text = "Update TLB";
            this.btnUp.UseVisualStyleBackColor = true;
            this.btnUp.Click += new System.EventHandler(this.btnUp_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.dataGridView1);
            this.groupBox2.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(572, 379);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox2.Size = new System.Drawing.Size(540, 259);
            this.groupBox2.TabIndex = 10;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "TLB";
            // 
            // tLB_TableBindingSource
            // 
            this.tLB_TableBindingSource.DataMember = "TLB Table";
            this.tLB_TableBindingSource.DataSource = this.tLB__tableDataSet;
            // 
            // tLB__tableDataSet
            // 
            this.tLB__tableDataSet.DataSetName = "TLB__tableDataSet";
            this.tLB__tableDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tLBTableAdapter
            // 
            this.tLBTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.TLBTableAdapter = this.tLBTableAdapter;
            this.tableAdapterManager.UpdateOrder = VIRTUAL_MEMORY.Database4DataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // tLB_TableTableAdapter
            // 
            this.tLB_TableTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager1
            // 
            this.tableAdapterManager1.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager1.TLB_TableTableAdapter = this.tLB_TableTableAdapter;
            this.tableAdapterManager1.UpdateOrder = VIRTUAL_MEMORY.TLB__tableDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // tLB__tableDataSet1
            // 
            this.tLB__tableDataSet1.DataSetName = "TLB__tableDataSet1";
            this.tLB__tableDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tLB_TableBindingSource1
            // 
            this.tLB_TableBindingSource1.DataMember = "TLB Table";
            this.tLB_TableBindingSource1.DataSource = this.tLB__tableDataSet1;
            // 
            // tLB_TableTableAdapter1
            // 
            this.tLB_TableTableAdapter1.ClearBeforeFill = true;
            // 
            // tableAdapterManager2
            // 
            this.tableAdapterManager2.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager2.TLB_TableTableAdapter = this.tLB_TableTableAdapter1;
            this.tableAdapterManager2.UpdateOrder = VIRTUAL_MEMORY.TLB__tableDataSet1TableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // database4DataSet1
            // 
            this.database4DataSet1.DataSetName = "Database4DataSet1";
            this.database4DataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tLBBindingSource1
            // 
            this.tLBBindingSource1.DataMember = "TLB";
            this.tLBBindingSource1.DataSource = this.database4DataSet1;
            // 
            // tLBTableAdapter1
            // 
            this.tLBTableAdapter1.ClearBeforeFill = true;
            // 
            // tableAdapterManager3
            // 
            this.tableAdapterManager3.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager3.TLBTableAdapter = this.tLBTableAdapter1;
            this.tableAdapterManager3.UpdateOrder = VIRTUAL_MEMORY.Database4DataSet1TableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.pageFrameNumberDataGridViewTextBoxColumn,
            this.physicalPageNumberDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.tLB_TableBindingSource2;
            this.dataGridView1.Location = new System.Drawing.Point(7, 27);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowTemplate.Height = 28;
            this.dataGridView1.Size = new System.Drawing.Size(508, 232);
            this.dataGridView1.TabIndex = 0;
            // 
            // tLB__tableDataSet2
            // 
            this.tLB__tableDataSet2.DataSetName = "TLB__tableDataSet2";
            this.tLB__tableDataSet2.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tLB_TableBindingSource2
            // 
            this.tLB_TableBindingSource2.DataMember = "TLB Table";
            this.tLB_TableBindingSource2.DataSource = this.tLB__tableDataSet2;
            // 
            // tLB_TableTableAdapter2
            // 
            this.tLB_TableTableAdapter2.ClearBeforeFill = true;
            // 
            // tableAdapterManager4
            // 
            this.tableAdapterManager4.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager4.TLB_TableTableAdapter = this.tLB_TableTableAdapter2;
            this.tableAdapterManager4.UpdateOrder = VIRTUAL_MEMORY.TLB__tableDataSet2TableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // pageFrameNumberDataGridViewTextBoxColumn
            // 
            this.pageFrameNumberDataGridViewTextBoxColumn.DataPropertyName = "Page_Frame_Number";
            this.pageFrameNumberDataGridViewTextBoxColumn.HeaderText = "Page_Frame_Number";
            this.pageFrameNumberDataGridViewTextBoxColumn.Name = "pageFrameNumberDataGridViewTextBoxColumn";
            // 
            // physicalPageNumberDataGridViewTextBoxColumn
            // 
            this.physicalPageNumberDataGridViewTextBoxColumn.DataPropertyName = "Physical_Page_Number";
            this.physicalPageNumberDataGridViewTextBoxColumn.HeaderText = "Physical_Page_Number";
            this.physicalPageNumberDataGridViewTextBoxColumn.Name = "physicalPageNumberDataGridViewTextBoxColumn";
            // 
            // dataGridView2
            // 
            this.dataGridView2.AutoGenerateColumns = false;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.frameNoDataGridViewTextBoxColumn,
            this.processDataGridViewTextBoxColumn,
            this.physicalPageNoDataGridViewTextBoxColumn});
            this.dataGridView2.DataSource = this.physical_MemoryBindingSource;
            this.dataGridView2.Location = new System.Drawing.Point(18, 27);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.RowTemplate.Height = 28;
            this.dataGridView2.Size = new System.Drawing.Size(499, 254);
            this.dataGridView2.TabIndex = 0;
            // 
            // virtualDataSet5
            // 
            this.virtualDataSet5.DataSetName = "virtualDataSet5";
            this.virtualDataSet5.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // physical_MemoryBindingSource
            // 
            this.physical_MemoryBindingSource.DataMember = "physical Memory";
            this.physical_MemoryBindingSource.DataSource = this.virtualDataSet5;
            // 
            // physical_MemoryTableAdapter
            // 
            this.physical_MemoryTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager5
            // 
            this.tableAdapterManager5.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager5.physical_MemoryTableAdapter = this.physical_MemoryTableAdapter;
            this.tableAdapterManager5.UpdateOrder = VIRTUAL_MEMORY.virtualDataSet5TableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // frameNoDataGridViewTextBoxColumn
            // 
            this.frameNoDataGridViewTextBoxColumn.DataPropertyName = "Frame_No";
            this.frameNoDataGridViewTextBoxColumn.HeaderText = "Frame_No";
            this.frameNoDataGridViewTextBoxColumn.Name = "frameNoDataGridViewTextBoxColumn";
            // 
            // processDataGridViewTextBoxColumn
            // 
            this.processDataGridViewTextBoxColumn.DataPropertyName = "Process";
            this.processDataGridViewTextBoxColumn.HeaderText = "Process";
            this.processDataGridViewTextBoxColumn.Name = "processDataGridViewTextBoxColumn";
            // 
            // physicalPageNoDataGridViewTextBoxColumn
            // 
            this.physicalPageNoDataGridViewTextBoxColumn.DataPropertyName = "Physical_Page_No";
            this.physicalPageNoDataGridViewTextBoxColumn.HeaderText = "Physical_Page_No";
            this.physicalPageNoDataGridViewTextBoxColumn.Name = "physicalPageNoDataGridViewTextBoxColumn";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1137, 846);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.btnUp);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.btnF);
            this.Controls.Add(this.btnE);
            this.Controls.Add(this.txtPro);
            this.Controls.Add(this.lblPHY);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lblProcess);
            this.Name = "Form1";
            this.Text = "VIRTUAL MEMORY";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.tLBBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.database4DataSet)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.tLB_TableBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tLB__tableDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tLB__tableDataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tLB_TableBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.database4DataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tLBBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tLB__tableDataSet2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tLB_TableBindingSource2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.virtualDataSet5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.physical_MemoryBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label lblProcess;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblPHY;
        private System.Windows.Forms.TextBox txtPro;
        private System.Windows.Forms.Button btnE;
        private System.Windows.Forms.Button btnF;
        private Database4DataSet database4DataSet;
        private System.Windows.Forms.BindingSource tLBBindingSource;
        private Database4DataSetTableAdapters.TLBTableAdapter tLBTableAdapter;
        private Database4DataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btnUp;
        private System.Windows.Forms.GroupBox groupBox2;
        private TLB__tableDataSet tLB__tableDataSet;
        private System.Windows.Forms.BindingSource tLB_TableBindingSource;
        private TLB__tableDataSetTableAdapters.TLB_TableTableAdapter tLB_TableTableAdapter;
        private TLB__tableDataSetTableAdapters.TableAdapterManager tableAdapterManager1;
        private TLB__tableDataSet1 tLB__tableDataSet1;
        private System.Windows.Forms.BindingSource tLB_TableBindingSource1;
        private TLB__tableDataSet1TableAdapters.TLB_TableTableAdapter tLB_TableTableAdapter1;
        private TLB__tableDataSet1TableAdapters.TableAdapterManager tableAdapterManager2;
        private Database4DataSet1 database4DataSet1;
        private System.Windows.Forms.BindingSource tLBBindingSource1;
        private Database4DataSet1TableAdapters.TLBTableAdapter tLBTableAdapter1;
        private Database4DataSet1TableAdapters.TableAdapterManager tableAdapterManager3;
        private System.Windows.Forms.DataGridView dataGridView1;
        private TLB__tableDataSet2 tLB__tableDataSet2;
        private System.Windows.Forms.BindingSource tLB_TableBindingSource2;
        private TLB__tableDataSet2TableAdapters.TLB_TableTableAdapter tLB_TableTableAdapter2;
        private TLB__tableDataSet2TableAdapters.TableAdapterManager tableAdapterManager4;
        private System.Windows.Forms.DataGridViewTextBoxColumn pageFrameNumberDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn physicalPageNumberDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridView dataGridView2;
        private virtualDataSet5 virtualDataSet5;
        private System.Windows.Forms.BindingSource physical_MemoryBindingSource;
        private virtualDataSet5TableAdapters.physical_MemoryTableAdapter physical_MemoryTableAdapter;
        private virtualDataSet5TableAdapters.TableAdapterManager tableAdapterManager5;
        private System.Windows.Forms.DataGridViewTextBoxColumn frameNoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn processDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn physicalPageNoDataGridViewTextBoxColumn;
    }
}

