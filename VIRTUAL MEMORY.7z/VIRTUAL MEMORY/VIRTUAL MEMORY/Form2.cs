﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace VIRTUAL_MEMORY
{
    public partial class Form2 : Form
    {
        public  OleDbConnection con = new OleDbConnection(Properties.Settings.Default.Database4ConnectionString);
       

        public static string SetValueForText1 = "";
        public static string SetValueForText2 = "";
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'database4DataSet1.TLB' table. You can move, or remove it, as needed.
            this.tLBTableAdapter.Fill(this.database4DataSet1.TLB);
            // TODO: This line of code loads data into the 'virtualDataSet5.physical_Memory' table. You can move, or remove it, as needed.
            this.physical_MemoryTableAdapter4.Fill(this.virtualDataSet5.physical_Memory);
            // TODO: This line of code loads data into the 'virtualDataSet3.physical_Memory' table. You can move, or remove it, as needed.
            this.physical_MemoryTableAdapter3.Fill(this.virtualDataSet3.physical_Memory);
            // TODO: This line of code loads data into the 'virtualDataSet2.physical_Memory' table. You can move, or remove it, as needed.
            this.physical_MemoryTableAdapter2.Fill(this.virtualDataSet2.physical_Memory);
            // TODO: This line of code loads data into the 'virtualDataSet1.physical_Memory' table. You can move, or remove it, as needed.
            this.physical_MemoryTableAdapter1.Fill(this.virtualDataSet1.physical_Memory);
            // TODO: This line of code loads data into the 'virtualDataSet.physical_Memory' table. You can move, or remove it, as needed.
            //this.physical_MemoryTableAdapter.Fill(this.virtualDataSet.physical_Memory);

        }

        public void display()
        {
            con.Open();
            OleDbDataAdapter ada = new OleDbDataAdapter("Select * From [TLB]", con);
            DataSet ds = new DataSet();
            ada.Fill(ds, "Tebogo");
            dataGridView1.DataSource = ds;
            dataGridView1.DataMember = "Tebogo";
            con.Close();

        }
        private void btnpR_Click(object sender, EventArgs e)
        {
            con.Open();
            OleDbCommand command = new OleDbCommand();
            command.Connection = con;
            command.CommandText = "select * from [TLB] where Process ='" + txtPro.Text + "'";
            OleDbDataReader reader = command.ExecuteReader();
            int count = 0;
            while (reader.Read())
            {
                count = count + 1;
            }
            if (count == 1)
            {

                MessageBox.Show("this page exist in the physical memory");

            }
            else if (count > 1)
            {
                MessageBox.Show("Duplicate page");
            }
            else
            {
                MessageBox.Show("remove first in page!", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
                OleDbCommand com = new OleDbCommand();
                com.Connection = con;
                com.CommandType = CommandType.Text;
                com.CommandText = "DELETE page  FROM [TLB]  WHERE Process ='" +txtEX.Text + "'";
                com.ExecuteNonQuery();
            }

            con.Close();
            display();
        }

        private void btnUp_Click(object sender, EventArgs e)
        {
            con.Open();
            try
            {
              
                OleDbCommand cod = new OleDbCommand();
                cod.Connection = con;
                cod.CommandText = "INSERT INTO [TLB]([Frame_No],[Process])  VALUES('" + txtFr.Text + "','" + txtPro.Text + "') ";
                cod.ExecuteNonQuery();
                MessageBox.Show("Page replacement successful! ","", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception)
            {

                MessageBox.Show("duplicate  page!", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
                Form1 s = new Form1();
                s.Show();
            }
            con.Close();
            display();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SetValueForText1 = txtFr.Text;
            SetValueForText2 = txtPro.Text;

            Form1 s = new Form1();
            s.Show();
           
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
